'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import VoiceAI from '@/components/VoiceAI';

export default function QuotePage() {
  const [messages, setMessages] = useState<{role: string, content: string}[]>([
    { role: 'assistant', content: 'Hi there! I\'m your insurance assistant. I can help you get a quote for home or auto insurance. What type of insurance are you interested in today?' }
  ]);
  
  const [insuranceType, setInsuranceType] = useState<'auto' | 'home' | 'bundle'>('auto');
  
  const [formData, setFormData] = useState({
    // Personal Information
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    
    // Auto specific
    vehicleYear: '',
    vehicleMake: '',
    vehicleModel: '',
    annualMileage: '',
    primaryUse: '',
    accidentHistory: '',
    
    // Home specific
    yearBuilt: '',
    squareFootage: '',
    constructionType: '',
    roofType: '',
    alarmSystem: false,
    smokeDetectors: false,
    fireExtinguishers: false,
    sprinklerSystem: false,
  });

  // This would be your actual VAPI public key in production
  const VAPI_PUBLIC_KEY = 'demo_pk_123456789';

  const handleMessageReceived = (message: any) => {
    console.log('Message received in parent component:', message);
    
    // Handle different message types from VAPI
    if (message.type === 'transcript') {
      // Add user message to chat
      setMessages(prev => [...prev, { role: 'user', content: message.transcript }]);
      
      // Detect insurance type from conversation
      const content = message.transcript.toLowerCase();
      if (content.includes('auto') || content.includes('car') || content.includes('vehicle')) {
        setInsuranceType('auto');
      } else if (content.includes('home') || content.includes('house') || content.includes('property')) {
        setInsuranceType('home');
      } else if (content.includes('bundle') || content.includes('both')) {
        setInsuranceType('bundle');
      }
    } else if (message.type === 'add-message' && message.message.role === 'assistant') {
      // Add assistant message to chat
      setMessages(prev => [...prev, { role: 'assistant', content: message.message.content }]);
    }
  };

  const handleFormDataUpdate = (newData: any) => {
    setFormData(prev => ({ ...prev, ...newData }));
  };

  const getCompletionPercentage = () => {
    let requiredFields = ['firstName', 'lastName', 'email', 'phone'];
    let totalFields = requiredFields.length;
    let completedFields = 0;
    
    // Add insurance-specific required fields
    if (insuranceType === 'auto' || insuranceType === 'bundle') {
      const autoFields = ['vehicleYear', 'vehicleMake', 'vehicleModel'];
      requiredFields = [...requiredFields, ...autoFields];
      totalFields += autoFields.length;
    }
    
    if (insuranceType === 'home' || insuranceType === 'bundle') {
      const homeFields = ['yearBuilt', 'squareFootage', 'constructionType'];
      requiredFields = [...requiredFields, ...homeFields];
      totalFields += homeFields.length;
    }
    
    // Count completed fields
    requiredFields.forEach(field => {
      if (formData[field as keyof typeof formData]) {
        completedFields++;
      }
    });
    
    return Math.round((completedFields / totalFields) * 100);
  };

  const isFormComplete = () => {
    return getCompletionPercentage() >= 70; // Consider form complete enough at 70%
  };

  const handleSubmitQuote = () => {
    alert(`Thank you! Your ${insuranceType} insurance quote request has been submitted. An agent will contact you shortly at ${formData.email || 'your email'}.`);
  };

  return (
    <main className="min-h-screen bg-[var(--progressive-gray-light)]">
      {/* Header */}
      <header className="progressive-header">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="logo">
            <Link href="/" className="text-2xl font-bold text-[var(--progressive-blue)]">InsuranceAI</Link>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Link href="#" className="text-[var(--progressive-text)] hover:text-[var(--progressive-blue)]">Explore Products</Link>
            <Link href="#" className="text-[var(--progressive-text)] hover:text-[var(--progressive-blue)]">Claims</Link>
            <Link href="#" className="text-[var(--progressive-text)] hover:text-[var(--progressive-blue)]">About Us</Link>
            <Link href="#" className="text-[var(--progressive-text)] hover:text-[var(--progressive-blue)]">Resources</Link>
          </nav>
          <div className="flex items-center space-x-4">
            <Link href="/quote-form/auto" className="text-[var(--progressive-blue)] hover:underline">Form Quote</Link>
            <Link href="#" className="text-[var(--progressive-blue)] hover:underline">Log In</Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Left column - Chat interface */}
          <div className="md:w-2/3">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-2xl font-semibold mb-6">Talk to our Insurance AI Assistant</h2>
              
              {/* Insurance type selector */}
              <div className="mb-6">
                <p className="text-sm text-gray-600 mb-2">Select insurance type to discuss:</p>
                <div className="flex space-x-2">
                  <button 
                    onClick={() => setInsuranceType('auto')}
                    className={`px-4 py-2 rounded-md ${insuranceType === 'auto' 
                      ? 'bg-[var(--progressive-blue)] text-white' 
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
                  >
                    Auto
                  </button>
                  <button 
                    onClick={() => setInsuranceType('home')}
                    className={`px-4 py-2 rounded-md ${insuranceType === 'home' 
                      ? 'bg-[var(--progressive-blue)] text-white' 
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
                  >
                    Home
                  </button>
                  <button 
                    onClick={() => setInsuranceType('bundle')}
                    className={`px-4 py-2 rounded-md ${insuranceType === 'bundle' 
                      ? 'bg-[var(--progressive-blue)] text-white' 
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
                  >
                    Bundle
                  </button>
                </div>
              </div>
              
              {/* Chat messages */}
              <div className="chat-messages bg-gray-50 rounded-lg p-4 mb-6 h-96 overflow-y-auto">
                {messages.map((msg, index) => (
                  <div 
                    key={index} 
                    className={`mb-4 ${msg.role === 'assistant' ? 'text-left' : 'text-right'}`}
                  >
                    <div 
                      className={`inline-block rounded-lg px-4 py-2 max-w-[80%] ${
                        msg.role === 'assistant' 
                          ? 'chat-message-assistant' 
                          : 'chat-message-user'
                      }`}
                    >
                      {msg.content}
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Voice AI component */}
              <VoiceAI 
                publicKey={VAPI_PUBLIC_KEY} 
                onMessageReceived={handleMessageReceived}
                onFormDataUpdate={handleFormDataUpdate}
                insuranceType={insuranceType}
              />
              
              <p className="text-sm text-gray-500 mt-4 text-center">
                You can speak with our AI assistant to get insurance quotes or provide your information for a follow-up.
              </p>
            </div>
          </div>
          
          {/* Right column - Form data */}
          <div className="md:w-1/3">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-2xl font-semibold mb-6">Your Quote Information</h2>
              
              {/* Progress indicator */}
              <div className="mb-6">
                <div className="flex justify-between text-sm mb-1">
                  <span>Quote completion</span>
                  <span>{getCompletionPercentage()}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div 
                    className="bg-[var(--progressive-blue)] h-2.5 rounded-full" 
                    style={{ width: `${getCompletionPercentage()}%` }}
                  ></div>
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium text-gray-700">Insurance Type</h3>
                  <p className="text-gray-900 capitalize">{insuranceType}</p>
                </div>
                
                <div>
                  <h3 className="font-medium text-gray-700">Contact Information</h3>
                  <p className="text-gray-900">Name: {formData.firstName ? `${formData.firstName} ${formData.lastName}` : 'Not provided'}</p>
                  <p className="text-gray-900">Email: {formData.email || 'Not provided'}</p>
                  <p className="text-gray-900">Phone: {formData.phone || 'Not provided'}</p>
                  <p className="text-gray-900">Address: {formData.address ? `${formData.address}, ${formData.city}, ${formData.state} ${formData.zipCode}` : 'Not provided'}</p>
                </div>
                
                {(insuranceType === 'auto' || insuranceType === 'bundle') && (
                  <div>
                    <h3 className="font-medium text-gray-700">Vehicle Information</h3>
                    <p className="text-gray-900">Year: {formData.vehicleYear || 'Not provided'}</p>
                    <p className="text-gray-900">Make: {formData.vehicleMake || 'Not provided'}</p>
                    <p className="text-gray-900">Model: {formData.vehicleModel || 'Not provided'}</p>
                    <p className="text-gray-900">Annual Mileage: {formData.annualMileage || 'Not provided'}</p>
                    <p className="text-gray-900">Primary Use: {formData.primaryUse || 'Not provided'}</p>
                    <p className="text-gray-900">Accident History: {formData.accidentHistory || 'Not provided'}</p>
                  </div>
                )}
                
                {(insuranceType === 'home' || insuranceType === 'bundle') && (
                  <div>
                    <h3 className="font-medium text-gray-700">Home Information</h3>
                    <p className="text-gray-900">Year Built: {formData.yearBuilt || 'Not provided'}</p>
                    <p className="text-gray-900">Size (sq ft): {formData.squareFootage || 'Not provided'}</p>
                    <p className="text-gray-900">Construction Type: {formData.constructionType || 'Not provided'}</p>
                    <p className="text-gray-900">Roof Type: {formData.roofType || 'Not provided'}</p>
                    <p className="text-gray-900">Safety Features: {
                      [
                        formData.alarmSystem ? 'Alarm System' : '',
                        formData.smokeDetectors ? 'Smoke Detectors' : '',
                        formData.fireExtinguishers ? 'Fire Extinguishers' : '',
                        formData.sprinklerSystem ? 'Sprinkler System' : ''
                      ].filter(Boolean).join(', ') || 'None specified'
                    }</p>
                  </div>
                )}
                
                <div className="pt-4">
                  <button 
                    className={`w-full px-4 py-2 rounded ${
                      isFormComplete() 
                        ? 'bg-[var(--progressive-blue)] text-white hover:bg-[var(--progressive-blue-light)]' 
                        : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    } transition-colors`}
                    disabled={!isFormComplete()}
                    onClick={handleSubmitQuote}
                  >
                    {isFormComplete() 
                      ? 'Submit Quote Request' 
                      : 'Please provide more information'}
                  </button>
                  
                  <p className="text-sm text-gray-500 mt-2 text-center">
                    Information will be sent to an agent who will contact you with a personalized quote.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Footer */}
      <footer className="progressive-footer mt-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h5 className="text-lg font-semibold mb-4">InsuranceAI</h5>
              <p className="text-gray-300">Innovative insurance solutions powered by AI technology.</p>
            </div>
            <div>
              <h5 className="text-lg font-semibold mb-4">Products</h5>
              <ul className="space-y-2">
                <li><Link href="/quote-form/auto" className="text-gray-300 hover:text-white">Auto Insurance</Link></li>
                <li><Link href="/quote-form/home" className="text-gray-300 hover:text-white">Home Insurance</Link></li>
                <li><Link href="#" className="text-gray-300 hover:text-white">Bundle & Save</Link></li>
              </ul>
            </div>
            <div>
              <h5 className="text-lg font-semibold mb-4">Resources</h5>
              <ul className="space-y-2">
                <li><Link href="#" className="text-gray-300 hover:text-white">Claims</Link></li>
                <li><Link href="#" className="text-gray-300 hover:text-white">Insurance Guide</Link></li>
                <li><Link href="#" className="text-gray-300 hover:text-white">FAQs</Link></li>
              </ul>
            </div>
            <div>
              <h5 className="text-lg font-semibold mb-4">Contact</h5>
              <address className="not-italic text-gray-300">
                <p>123 Insurance Way</p>
                <p>Anytown, USA 12345</p>
                <p className="mt-2">Phone: (555) 123-4567</p>
                <p>Email: info@insuranceai.com</p>
              </address>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-300">
            <p>&copy; {new Date().getFullYear()} InsuranceAI. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </main>
  );
}
