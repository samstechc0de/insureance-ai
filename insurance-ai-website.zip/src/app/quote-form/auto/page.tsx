'use client';

import React, { useState } from 'react';
import Link from 'next/link';

// Auto Insurance Quote Form Component
export default function AutoQuoteForm() {
  const [formData, setFormData] = useState({
    // Personal Information
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    
    // Vehicle Information
    vehicleYear: '',
    vehicleMake: '',
    vehicleModel: '',
    vin: '',
    annualMileage: '',
    primaryUse: 'commute',
    
    // Driver Information
    licenseNumber: '',
    yearsOfExperience: '',
    accidentHistory: 'none',
    
    // Coverage Options
    liabilityCoverage: true,
    comprehensiveCoverage: true,
    collisionCoverage: true,
    uninsuredMotorist: true,
    medicalPayments: true,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    
    // Handle checkbox inputs
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    // Here you would typically send the data to your backend
    alert('Quote request submitted! An agent will contact you shortly.');
  };

  return (
    <main className="min-h-screen bg-[var(--progressive-gray-light)]">
      {/* Header */}
      <header className="progressive-header">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="logo">
            <Link href="/" className="text-2xl font-bold text-[var(--progressive-blue)]">InsuranceAI</Link>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Link href="#" className="text-[var(--progressive-text)] hover:text-[var(--progressive-blue)]">Explore Products</Link>
            <Link href="#" className="text-[var(--progressive-text)] hover:text-[var(--progressive-blue)]">Claims</Link>
            <Link href="#" className="text-[var(--progressive-text)] hover:text-[var(--progressive-blue)]">About Us</Link>
            <Link href="#" className="text-[var(--progressive-text)] hover:text-[var(--progressive-blue)]">Resources</Link>
          </nav>
          <div className="flex items-center space-x-4">
            <Link href="/quote" className="text-[var(--progressive-blue)] hover:underline">Voice Quote</Link>
            <Link href="#" className="text-[var(--progressive-blue)] hover:underline">Log In</Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-[var(--progressive-text)]">Auto Insurance Quote</h1>
          <p className="text-[var(--progressive-gray-dark)]">Fill out the form below to get your personalized auto insurance quote.</p>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Personal Information Section */}
          <div className="form-section">
            <h2 className="form-section-title">Personal Information</h2>
            <div className="form-grid">
              <div>
                <label htmlFor="firstName" className="progressive-label">First Name</label>
                <input
                  type="text"
                  id="firstName"
                  name="firstName"
                  value={formData.firstName}
                  onChange={handleChange}
                  className="progressive-input"
                  required
                />
              </div>
              <div>
                <label htmlFor="lastName" className="progressive-label">Last Name</label>
                <input
                  type="text"
                  id="lastName"
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleChange}
                  className="progressive-input"
                  required
                />
              </div>
              <div>
                <label htmlFor="dateOfBirth" className="progressive-label">Date of Birth</label>
                <input
                  type="date"
                  id="dateOfBirth"
                  name="dateOfBirth"
                  value={formData.dateOfBirth}
                  onChange={handleChange}
                  className="progressive-input"
                  required
                />
              </div>
              <div>
                <label htmlFor="email" className="progressive-label">Email Address</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  className="progressive-input"
                  required
                />
              </div>
              <div>
                <label htmlFor="phone" className="progressive-label">Phone Number</label>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  className="progressive-input"
                  required
                />
              </div>
              <div className="form-full-width">
                <label htmlFor="address" className="progressive-label">Street Address</label>
                <input
                  type="text"
                  id="address"
                  name="address"
                  value={formData.address}
                  onChange={handleChange}
                  className="progressive-input"
                  required
                />
              </div>
              <div>
                <label htmlFor="city" className="progressive-label">City</label>
                <input
                  type="text"
                  id="city"
                  name="city"
                  value={formData.city}
                  onChange={handleChange}
                  className="progressive-input"
                  required
                />
              </div>
              <div>
                <label htmlFor="state" className="progressive-label">State</label>
                <select
                  id="state"
                  name="state"
                  value={formData.state}
                  onChange={handleChange}
                  className="progressive-select"
                  required
                >
                  <option value="">Select State</option>
                  <option value="AL">Alabama</option>
                  <option value="AK">Alaska</option>
                  <option value="AZ">Arizona</option>
                  {/* Add all states here */}
                  <option value="CA">California</option>
                  <option value="NY">New York</option>
                  <option value="TX">Texas</option>
                </select>
              </div>
              <div>
                <label htmlFor="zipCode" className="progressive-label">ZIP Code</label>
                <input
                  type="text"
                  id="zipCode"
                  name="zipCode"
                  value={formData.zipCode}
                  onChange={handleChange}
                  className="progressive-input"
                  required
                />
              </div>
            </div>
          </div>

          {/* Vehicle Information Section */}
          <div className="form-section">
            <h2 className="form-section-title">Vehicle Information</h2>
            <div className="form-grid">
              <div>
                <label htmlFor="vehicleYear" className="progressive-label">Vehicle Year</label>
                <input
                  type="number"
                  id="vehicleYear"
                  name="vehicleYear"
                  value={formData.vehicleYear}
                  onChange={handleChange}
                  className="progressive-input"
                  min="1900"
                  max={new Date().getFullYear() + 1}
                  required
                />
              </div>
              <div>
                <label htmlFor="vehicleMake" className="progressive-label">Vehicle Make</label>
                <input
                  type="text"
                  id="vehicleMake"
                  name="vehicleMake"
                  value={formData.vehicleMake}
                  onChange={handleChange}
                  className="progressive-input"
                  required
                />
              </div>
              <div>
                <label htmlFor="vehicleModel" className="progressive-label">Vehicle Model</label>
                <input
                  type="text"
                  id="vehicleModel"
                  name="vehicleModel"
                  value={formData.vehicleModel}
                  onChange={handleChange}
                  className="progressive-input"
                  required
                />
              </div>
              <div>
                <label htmlFor="vin" className="progressive-label">VIN (Optional)</label>
                <input
                  type="text"
                  id="vin"
                  name="vin"
                  value={formData.vin}
                  onChange={handleChange}
                  className="progressive-input"
                />
              </div>
              <div>
                <label htmlFor="annualMileage" className="progressive-label">Annual Mileage</label>
                <input
                  type="number"
                  id="annualMileage"
                  name="annualMileage"
                  value={formData.annualMileage}
                  onChange={handleChange}
                  className="progressive-input"
                  required
                />
              </div>
              <div>
                <label htmlFor="primaryUse" className="progressive-label">Primary Use</label>
                <select
                  id="primaryUse"
                  name="primaryUse"
                  value={formData.primaryUse}
                  onChange={handleChange}
                  className="progressive-select"
                  required
                >
                  <option value="commute">Commute</option>
                  <option value="pleasure">Pleasure</option>
                  <option value="business">Business</option>
                </select>
              </div>
            </div>
          </div>

          {/* Driver Information Section */}
          <div className="form-section">
            <h2 className="form-section-title">Driver Information</h2>
            <div className="form-grid">
              <div>
                <label htmlFor="licenseNumber" className="progressive-label">License Number</label>
                <input
                  type="text"
                  id="licenseNumber"
                  name="licenseNumber"
                  value={formData.licenseNumber}
                  onChange={handleChange}
                  className="progressive-input"
                  required
                />
              </div>
              <div>
                <label htmlFor="yearsOfExperience" className="progressive-label">Years of Driving Experience</label>
                <input
                  type="number"
                  id="yearsOfExperience"
                  name="yearsOfExperience"
                  value={formData.yearsOfExperience}
                  onChange={handleChange}
                  className="progressive-input"
                  min="0"
                  max="99"
                  required
                />
              </div>
              <div className="form-full-width">
                <label htmlFor="accidentHistory" className="progressive-label">Accident/Violation History (Last 3 Years)</label>
                <select
                  id="accidentHistory"
                  name="accidentHistory"
                  value={formData.accidentHistory}
                  onChange={handleChange}
                  className="progressive-select"
                  required
                >
                  <option value="none">No Accidents or Violations</option>
                  <option value="accident">One or More Accidents</option>
                  <option value="violation">One or More Violations</option>
                  <option value="both">Both Accidents and Violations</option>
                </select>
              </div>
            </div>
          </div>

          {/* Coverage Options Section */}
          <div className="form-section">
            <h2 className="form-section-title">Coverage Options</h2>
            <div className="space-y-4">
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="liabilityCoverage"
                  name="liabilityCoverage"
                  checked={formData.liabilityCoverage}
                  onChange={handleChange}
                  className="h-5 w-5 text-[var(--progressive-blue)]"
                />
                <label htmlFor="liabilityCoverage" className="ml-2 text-[var(--progressive-text)]">
                  Liability Coverage
                </label>
              </div>
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="comprehensiveCoverage"
                  name="comprehensiveCoverage"
                  checked={formData.comprehensiveCoverage}
                  onChange={handleChange}
                  className="h-5 w-5 text-[var(--progressive-blue)]"
                />
                <label htmlFor="comprehensiveCoverage" className="ml-2 text-[var(--progressive-text)]">
                  Comprehensive Coverage
                </label>
              </div>
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="collisionCoverage"
                  name="collisionCoverage"
                  checked={formData.collisionCoverage}
                  onChange={handleChange}
                  className="h-5 w-5 text-[var(--progressive-blue)]"
                />
                <label htmlFor="collisionCoverage" className="ml-2 text-[var(--progressive-text)]">
                  Collision Coverage
                </label>
              </div>
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="uninsuredMotorist"
                  name="uninsuredMotorist"
                  checked={formData.uninsuredMotorist}
                  onChange={handleChange}
                  className="h-5 w-5 text-[var(--progressive-blue)]"
                />
                <label htmlFor="uninsuredMotorist" className="ml-2 text-[var(--progressive-text)]">
                  Uninsured/Underinsured Motorist
                </label>
              </div>
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="medicalPayments"
                  name="medicalPayments"
                  checked={formData.medicalPayments}
                  onChange={handleChange}
                  className="h-5 w-5 text-[var(--progressive-blue)]"
                />
                <label htmlFor="medicalPayments" className="ml-2 text-[var(--progressive-text)]">
                  Medical Payments/Personal Injury Protection
                </label>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <div className="mt-8 flex justify-center">
            <button type="submit" className="progressive-button">
              Get My Quote
            </button>
          </div>
        </form>
      </div>

      {/* Footer */}
      <footer className="progressive-footer mt-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h5 className="text-lg font-semibold mb-4">InsuranceAI</h5>
              <p className="text-gray-300">Innovative insurance solutions powered by AI technology.</p>
            </div>
            <div>
              <h5 className="text-lg font-semibold mb-4">Products</h5>
              <ul className="space-y-2">
                <li><Link href="#" className="text-gray-300 hover:text-white">Auto Insurance</Link></li>
                <li><Link href="#" className="text-gray-300 hover:text-white">Home Insurance</Link></li>
                <li><Link href="#" className="text-gray-300 hover:text-white">Bundle & Save</Link></li>
              </ul>
            </div>
            <div>
              <h5 className="text-lg font-semibold mb-4">Resources</h5>
              <ul className="space-y-2">
                <li><Link href="#" className="text-gray-300 hover:text-white">Claims</Link></li>
                <li><Link href="#" className="text-gray-300 hover:text-white">Insurance Guide</Link></li>
                <li><Link href="#" className="text-gray-300 hover:text-white">FAQs</Link></li>
              </ul>
            </div>
            <div>
              <h5 className="text-lg font-semibold mb-4">Contact</h5>
              <address className="not-italic text-gray-300">
                <p>123 Insurance Way</p>
                <p>Anytown, USA 12345</p>
                <p className="mt-2">Phone: (555) 123-4567</p>
                <p>Email: info@insuranceai.com</p>
              </address>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-300">
            <p>&copy; {new Date().getFullYear()} InsuranceAI. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </main>
  );
}
