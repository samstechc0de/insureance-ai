import Image from 'next/image';
import Link from 'next/link';

export default function Home() {
  return (
    <main className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="logo">
            <h1 className="text-2xl font-bold text-blue-700">InsuranceAI</h1>
          </div>
          <nav className="hidden md:flex space-x-6">
            <Link href="#" className="text-gray-700 hover:text-blue-700">Explore Products</Link>
            <Link href="#" className="text-gray-700 hover:text-blue-700">Claims</Link>
            <Link href="#" className="text-gray-700 hover:text-blue-700">About Us</Link>
            <Link href="#" className="text-gray-700 hover:text-blue-700">Resources</Link>
          </nav>
          <div className="flex items-center space-x-4">
            <Link href="#" className="text-blue-700 hover:underline">Log In</Link>
            <Link href="#" className="hidden md:inline-block px-4 py-2 bg-blue-700 text-white rounded hover:bg-blue-800">Get a Quote</Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-50 to-white">
        <div className="container mx-auto px-4 py-16 md:py-24 flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">Better insurance starts here</h2>
            <p className="text-lg text-gray-600 mb-8">Talk to our AI assistant to get personalized quotes for home and auto insurance in minutes.</p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <Link href="/quote" className="px-6 py-3 bg-blue-700 text-white rounded-md text-center hover:bg-blue-800 transition">
                Start Voice Chat
              </Link>
              <Link href="/quote-form" className="px-6 py-3 border border-blue-700 text-blue-700 rounded-md text-center hover:bg-blue-50 transition">
                Use Quote Form
              </Link>
            </div>
          </div>
          <div className="md:w-1/2">
            <div className="relative h-64 md:h-96 w-full">
              <div className="absolute inset-0 bg-blue-100 rounded-lg overflow-hidden">
                {/* Placeholder for an image - would be replaced with actual image in production */}
                <div className="w-full h-full flex items-center justify-center">
                  <span className="text-blue-700 text-lg">Family image would go here</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Product Selection */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <h3 className="text-2xl font-semibold text-center mb-8">Select a product to quote</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Auto Insurance */}
            <div className="bg-blue-50 rounded-lg p-6 border border-blue-100 hover:shadow-md transition">
              <div className="flex items-start mb-4">
                <div className="bg-blue-100 p-3 rounded-full mr-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
                <div>
                  <h4 className="text-xl font-semibold text-gray-800">Auto Insurance</h4>
                  <p className="text-gray-600">Average savings of over $800</p>
                </div>
              </div>
              <Link href="/quote/auto" className="text-blue-700 font-medium hover:underline flex items-center">
                Get a quote
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </Link>
            </div>

            {/* Home Insurance */}
            <div className="bg-blue-50 rounded-lg p-6 border border-blue-100 hover:shadow-md transition">
              <div className="flex items-start mb-4">
                <div className="bg-blue-100 p-3 rounded-full mr-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-blue-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                  </svg>
                </div>
                <div>
                  <h4 className="text-xl font-semibold text-gray-800">Home Insurance</h4>
                  <p className="text-gray-600">Protect your home & belongings</p>
                </div>
              </div>
              <Link href="/quote/home" className="text-blue-700 font-medium hover:underline flex items-center">
                Get a quote
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </Link>
            </div>

            {/* Bundle & Save */}
            <div className="bg-green-50 rounded-lg p-6 border border-green-100 hover:shadow-md transition">
              <div className="flex items-start mb-4">
                <div className="bg-green-100 p-3 rounded-full mr-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-green-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <h4 className="text-xl font-semibold text-gray-800">Bundle & Save</h4>
                  <p className="text-gray-600">Auto + home for extra savings</p>
                </div>
              </div>
              <Link href="/quote/bundle" className="text-green-700 font-medium hover:underline flex items-center">
                Get a quote
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h3 className="text-2xl font-semibold text-center mb-8">Why Choose Our Insurance</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h4 className="text-xl font-semibold mb-2">Quick & Easy</h4>
              <p className="text-gray-600">Get quotes in minutes with our AI assistant or simple online forms.</p>
            </div>
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              <h4 className="text-xl font-semibold mb-2">Reliable Coverage</h4>
              <p className="text-gray-600">Comprehensive protection for what matters most to you.</p>
            </div>
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-blue-700" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <h4 className="text-xl font-semibold mb-2">Affordable Rates</h4>
              <p className="text-gray-600">Competitive pricing with discounts and savings opportunities.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h5 className="text-lg font-semibold mb-4">InsuranceAI</h5>
              <p className="text-gray-400">Innovative insurance solutions powered by AI technology.</p>
            </div>
            <div>
              <h5 className="text-lg font-semibold mb-4">Products</h5>
              <ul className="space-y-2">
                <li><Link href="#" className="text-gray-400 hover:text-white">Auto Insurance</Link></li>
                <li><Link href="#" className="text-gray-400 hover:text-white">Home Insurance</Link></li>
                <li><Link href="#" className="text-gray-400 hover:text-white">Bundle & Save</Link></li>
                <li><Link href="#" className="text-gray-400 hover:text-white">All Products</Link></li>
              </ul>
            </div>
            <div>
              <h5 className="text-lg font-semibold mb-4">Resources</h5>
              <ul className="space-y-2">
                <li><Link href="#" className="text-gray-400 hover:text-white">Claims</Link></li>
                <li><Link href="#" className="text-gray-400 hover:text-white">Insurance Guide</Link></li>
                <li><Link href="#" className="text-gray-400 hover:text-white">FAQs</Link></li>
                <li><Link href="#" className="text-gray-400 hover:text-white">Contact Us</Link></li>
              </ul>
            </div>
            <div>
              <h5 className="text-lg font-semibold mb-4">Contact</h5>
              <address className="not-italic text-gray-400">
                <p>123 Insurance Way</p>
                <p>Anytown, USA 12345</p>
                <p className="mt-2">Phone: (555) 123-4567</p>
                <p>Email: info@insuranceai.com</p>
              </address>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} InsuranceAI. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </main>
  );
}
