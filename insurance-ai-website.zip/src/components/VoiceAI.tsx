'use client';

import React, { useState, useEffect, useRef } from 'react';
import { Vapi } from '@vapi-ai/web';

interface VoiceAIProps {
  publicKey: string;
  assistantId?: string;
  onMessageReceived?: (message: any) => void;
  onFormDataUpdate?: (formData: any) => void;
  insuranceType?: 'auto' | 'home' | 'bundle';
}

const VoiceAI: React.FC<VoiceAIProps> = ({ 
  publicKey, 
  assistantId = "87c43fa1-9821-45c1-9f1e-17e9f92800ed", // User's specific VAPI assistant ID
  onMessageReceived,
  onFormDataUpdate,
  insuranceType = 'auto'
}) => {
  const [isCallActive, setIsCallActive] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [statusMessage, setStatusMessage] = useState('Click to start voice interaction');
  const [volumeLevel, setVolumeLevel] = useState(0);
  const [isListening, setIsListening] = useState(false);
  const vapiInstanceRef = useRef<Vapi | null>(null);
  const callRef = useRef<any | null>(null);

  // Create conversation prompts based on insurance type
  const getAssistantConfig = () => {
    let systemPrompt = `You are an insurance assistant helping customers get quotes for ${insuranceType} insurance. 
    Be friendly, professional, and helpful. Ask for information one question at a time.
    Extract relevant information from the customer's responses and provide it back to the system.
    When you've collected enough information, let the customer know you'll be sending their information to an agent.`;
    
    let firstMessage = "Hi there! I'm your insurance assistant. ";
    
    if (insuranceType === 'auto') {
      systemPrompt += `
      For auto insurance, collect the following information:
      - Customer's full name
      - Email and phone number
      - Vehicle year, make, and model
      - Primary use of vehicle (commute, pleasure, business)
      - Approximate annual mileage
      - Any accidents or violations in the past 3 years`;
      
      firstMessage += "I can help you get a quote for auto insurance. Could you start by telling me your full name?";
    } 
    else if (insuranceType === 'home') {
      systemPrompt += `
      For home insurance, collect the following information:
      - Customer's full name
      - Email and phone number
      - Property address
      - Year the home was built
      - Square footage
      - Type of construction
      - Any safety features like alarm systems or smoke detectors`;
      
      firstMessage += "I can help you get a quote for home insurance. Could you start by telling me your full name?";
    }
    else if (insuranceType === 'bundle') {
      systemPrompt += `
      For bundled insurance, collect information for both auto and home:
      - Customer's full name
      - Email and phone number
      - Vehicle information: year, make, model
      - Home information: address, year built, square footage
      - Explain the benefits of bundling both policies`;
      
      firstMessage += "I can help you get a quote for bundled auto and home insurance, which can save you money. Could you start by telling me your full name?";
    }
    
    return {
      name: `${insuranceType.charAt(0).toUpperCase() + insuranceType.slice(1)} Insurance Assistant`,
      model: {
        provider: "openai",
        model: "gpt-4",
        temperature: 0.7,
        systemPrompt: systemPrompt
      },
      voice: {
        provider: "openai",
        voiceId: "alloy",
      },
      firstMessage: firstMessage,
      options: {
        endCallOnSilence: 5,
        useAssistantInstructions: true,
      }
    };
  };

  useEffect(() => {
    // Initialize Vapi instance
    if (!vapiInstanceRef.current) {
      vapiInstanceRef.current = new Vapi(publicKey);
      
      // Set up event listeners
      if (vapiInstanceRef.current) {
        vapiInstanceRef.current.on('call-start', () => {
          setIsCallActive(true);
          setStatusMessage('Call started. Speak now...');
        });

        vapiInstanceRef.current.on('call-end', () => {
          setIsCallActive(false);
          setStatusMessage('Call ended');
          setIsListening(false);
          callRef.current = null;
        });

        vapiInstanceRef.current.on('speech-start', () => {
          setStatusMessage('AI is speaking...');
          setIsListening(false);
        });

        vapiInstanceRef.current.on('speech-end', () => {
          setStatusMessage('AI finished speaking. Your turn...');
          setIsListening(true);
        });

        vapiInstanceRef.current.on('volume-level', (level) => {
          setVolumeLevel(level);
        });

        vapiInstanceRef.current.on('message', (message) => {
          console.log('Message received:', message);
          
          if (onMessageReceived) {
            onMessageReceived(message);
          }
          
          // Extract form data from messages
          if (message.type === 'transcript' && onFormDataUpdate) {
            extractFormData(message.transcript);
          } else if (message.type === 'add-message' && message.message.role === 'assistant' && onFormDataUpdate) {
            // The assistant might also provide structured data
            if (message.message.content) {
              extractFormData(message.message.content);
            }
          }
        });

        vapiInstanceRef.current.on('error', (error) => {
          console.error('Vapi error:', error);
          setStatusMessage('Error: ' + error.message);
          setIsCallActive(false);
          setIsListening(false);
        });
      }
    }

    return () => {
      // Clean up
      if (callRef.current) {
        callRef.current.stop();
      }
    };
  }, [publicKey, onMessageReceived, onFormDataUpdate]);

  const extractFormData = (text: string) => {
    if (!onFormDataUpdate) return;
    
    const formData: any = {};
    const lowerText = text.toLowerCase();
    
    // Extract name
    const nameMatch = text.match(/(?:my name is|i am|i'm) ([A-Za-z]+(?: [A-Za-z]+){1,2})/i);
    if (nameMatch && nameMatch[1]) {
      const fullName = nameMatch[1].trim();
      const nameParts = fullName.split(' ');
      if (nameParts.length >= 2) {
        formData.firstName = nameParts[0];
        formData.lastName = nameParts.slice(1).join(' ');
      } else {
        formData.firstName = fullName;
      }
    }
    
    // Extract email
    const emailMatch = text.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/i);
    if (emailMatch && emailMatch[1]) {
      formData.email = emailMatch[1];
    }
    
    // Extract phone
    const phoneMatch = text.match(/(\d{3}[-.\s]?\d{3}[-.\s]?\d{4}|\(\d{3}\)\s*\d{3}[-.\s]?\d{4}|\d{10})/);
    if (phoneMatch && phoneMatch[0]) {
      formData.phone = phoneMatch[0];
    }
    
    // Extract address components
    const addressMatch = text.match(/(?:address is|live at|located at) ([^,]+),?\s*([^,]+),?\s*([A-Z]{2})\s*(\d{5})?/i);
    if (addressMatch) {
      formData.address = addressMatch[1];
      if (addressMatch[2]) formData.city = addressMatch[2];
      if (addressMatch[3]) formData.state = addressMatch[3];
      if (addressMatch[4]) formData.zipCode = addressMatch[4];
    }
    
    // Auto insurance specific
    if (insuranceType === 'auto' || insuranceType === 'bundle') {
      // Extract vehicle year
      const yearMatch = text.match(/(?:vehicle|car) (?:is|from) (?:a |an )?(\d{4})/i) || 
                        text.match(/(\d{4}) (?:vehicle|car|model)/i);
      if (yearMatch && yearMatch[1]) {
        formData.vehicleYear = yearMatch[1];
      }
      
      // Extract vehicle make and model
      const makeModelMatch = text.match(/(?:drive|have|own) (?:a |an )?(\w+) (\w+)/i);
      if (makeModelMatch) {
        formData.vehicleMake = makeModelMatch[1];
        formData.vehicleModel = makeModelMatch[2];
      }
      
      // Extract mileage
      const mileageMatch = text.match(/(\d{1,3}(?:,\d{3})*|\d+) (?:miles|mileage)/i);
      if (mileageMatch && mileageMatch[1]) {
        formData.annualMileage = mileageMatch[1].replace(/,/g, '');
      }
      
      // Extract primary use
      if (lowerText.includes('commut') || lowerText.includes('work') || lowerText.includes('office')) {
        formData.primaryUse = 'commute';
      } else if (lowerText.includes('business') || lowerText.includes('commercial')) {
        formData.primaryUse = 'business';
      } else if (lowerText.includes('pleasure') || lowerText.includes('personal')) {
        formData.primaryUse = 'pleasure';
      }
      
      // Extract accident history
      if (lowerText.includes('no accident') || lowerText.includes('never had an accident')) {
        formData.accidentHistory = 'none';
      } else if (lowerText.includes('accident')) {
        formData.accidentHistory = 'accident';
      }
    }
    
    // Home insurance specific
    if (insuranceType === 'home' || insuranceType === 'bundle') {
      // Extract year built
      const yearBuiltMatch = text.match(/built in (\d{4})/i) || 
                             text.match(/house is (?:from|built) (\d{4})/i);
      if (yearBuiltMatch && yearBuiltMatch[1]) {
        formData.yearBuilt = yearBuiltMatch[1];
      }
      
      // Extract square footage
      const sqftMatch = text.match(/(\d{1,3}(?:,\d{3})*|\d+) (?:square feet|sq ft|sqft)/i);
      if (sqftMatch && sqftMatch[1]) {
        formData.squareFootage = sqftMatch[1].replace(/,/g, '');
      }
      
      // Extract construction type
      if (lowerText.includes('wood frame') || lowerText.includes('wooden')) {
        formData.constructionType = 'wood';
      } else if (lowerText.includes('brick')) {
        formData.constructionType = 'brick';
      } else if (lowerText.includes('concrete')) {
        formData.constructionType = 'concrete';
      } else if (lowerText.includes('steel')) {
        formData.constructionType = 'steel';
      }
      
      // Extract safety features
      if (lowerText.includes('alarm')) {
        formData.alarmSystem = true;
      }
      if (lowerText.includes('smoke detector')) {
        formData.smokeDetectors = true;
      }
      if (lowerText.includes('fire extinguisher')) {
        formData.fireExtinguishers = true;
      }
      if (lowerText.includes('sprinkler')) {
        formData.sprinklerSystem = true;
      }
    }
    
    if (Object.keys(formData).length > 0) {
      onFormDataUpdate(formData);
    }
  };

  const startCall = async () => {
    if (!vapiInstanceRef.current) return;
    
    try {
      setStatusMessage('Starting call...');
      
      // Use the user's specific VAPI assistant ID
      callRef.current = await vapiInstanceRef.current.start(assistantId);
    } catch (error) {
      console.error('Error starting call:', error);
      setStatusMessage('Failed to start call');
    }
  };

  const stopCall = () => {
    if (callRef.current) {
      callRef.current.stop();
      setStatusMessage('Ending call...');
    }
  };

  const toggleMute = () => {
    if (callRef.current) {
      const newMuteState = !isMuted;
      callRef.current.setMuted(newMuteState);
      setIsMuted(newMuteState);
      setStatusMessage(newMuteState ? 'Microphone muted' : 'Microphone unmuted');
    }
  };

  const sendMessage = (message: string) => {
    if (callRef.current) {
      callRef.current.send({
        type: 'add-message',
        message: {
          role: 'user',
          content: message
        }
      });
    }
  };

  return (
    <div className="voice-ai-container p-4 bg-white rounded-lg shadow-md">
      <div className="status-indicator mb-4 text-center">
        <p className={`text-sm ${isCallActive ? 'text-green-600' : 'text-gray-600'}`}>
          {statusMessage}
        </p>
        
        {isCallActive && (
          <div className="mt-2 flex justify-center items-center">
            <div className="relative w-48 h-2 bg-gray-200 rounded-full overflow-hidden">
              <div 
                className={`absolute top-0 left-0 h-full ${isListening ? 'bg-green-500' : 'bg-blue-500'}`} 
                style={{ width: `${volumeLevel * 100}%` }}
              ></div>
            </div>
            <span className="ml-2 text-xs text-gray-500">
              {isListening ? 'Listening...' : 'AI Speaking'}
            </span>
          </div>
        )}
      </div>
      
      <div className="flex justify-center space-x-4">
        {!isCallActive ? (
          <button
            onClick={startCall}
            className="voice-button"
            aria-label="Start voice assistant"
          >
            <span className="mr-2">Start Voice Assistant</span>
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"></path>
              <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
              <line x1="12" x2="12" y1="19" y2="22"></line>
            </svg>
          </button>
        ) : (
          <>
            <button
              onClick={toggleMute}
              className={`px-4 py-2 ${isMuted ? 'bg-red-600' : 'bg-gray-600'} text-white rounded-full hover:opacity-90 transition-colors flex items-center`}
              aria-label={isMuted ? "Unmute microphone" : "Mute microphone"}
            >
              {isMuted ? (
                <>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                    <line x1="1" y1="1" x2="23" y2="23"></line>
                    <path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V5a3 3 0 0 0-5.94-.6"></path>
                    <path d="M17 16.95A7 7 0 0 1 5 12v-2m14 0v2a7 7 0 0 1-.11 1.23"></path>
                    <line x1="12" x2="12" y1="19" y2="23"></line>
                    <line x1="8" x2="16" y1="23" y2="23"></line>
                  </svg>
                  Unmute
                </>
              ) : (
                <>
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                    <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"></path>
                    <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
                    <line x1="12" x2="12" y1="19" y2="23"></line>
                    <line x1="8" x2="16" y1="23" y2="23"></line>
                  </svg>
                  Mute
                </>
              )}
            </button>
            <button
              onClick={stopCall}
              className="voice-button-end flex items-center"
              aria-label="End call"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1">
                <path d="M16 2v4"></path>
                <path d="M8 2v4"></path>
                <path d="M15.5 9.5l-7 7"></path>
                <path d="M8.5 9.5l7 7"></path>
                <path d="M19 15v4"></path>
                <path d="M5 15v4"></path>
              </svg>
              End Call
            </button>
          </>
        )}
      </div>
      
      <div className="mt-4 text-center">
        <p className="text-sm text-gray-500">
          {isCallActive 
            ? "Speak clearly and answer the assistant's questions to get your insurance quote." 
            : "Click the button above to start talking with our AI assistant."}
        </p>
      </div>
    </div>
  );
};

export default VoiceAI;
